# PHB God Code Rootless Tree Environment Variables with BusyBox
export PHB_ROOTLESS_TREE_ACTIVE=1
export PATH="/data/data/com.termux/files/home/GCS/rootless_tree/bin:$PATH"
export PHB_SCAFFOLD_PATH="/data/data/com.termux/files/home/GCS/rootless_tree/phb_scaffold"
