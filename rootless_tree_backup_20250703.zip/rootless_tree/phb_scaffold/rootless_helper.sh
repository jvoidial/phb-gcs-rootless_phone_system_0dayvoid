#!/data/data/com.termux/files/usr/bin/bash
echo "[⚙️] PHB Rootless Helper running..."
echo "Rootless tree active: $PHB_ROOTLESS_TREE_ACTIVE"
echo "Scaffold path: $PHB_SCAFFOLD_PATH"
# Add your custom rootless patches or commands here
