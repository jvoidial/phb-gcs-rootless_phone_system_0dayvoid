#!/system/bin/sh
echo "PHB Rootless Helper Active"
echo "Extend this script to test exploits or environment variables."
